$(document).ready(function() {
    var clipboard = new ClipboardJS('.umicons__box');
});
